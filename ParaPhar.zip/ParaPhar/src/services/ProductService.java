/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import com.codename1.io.CharArrayReader;
import com.codename1.io.ConnectionRequest;
import com.codename1.io.JSONParser;
import com.codename1.io.NetworkManager;
import entities.Product;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import entities.Store;
import entities.User;
import views.HiddenObj;

/**
 *
 * @author KattaX
 */
public class ProductService {

    private ConnectionRequest con;
    private JSONParser jSONParser;

    public ProductService() {
        con = new ConnectionRequest();

        jSONParser = new JSONParser();
    }

    public List<Product> getAll() {
        List<Product> products = new ArrayList<>();
        con.setUrl("http://127.0.0.1:8000/api/GetProducts");
        con.setPost(false);
        con.addResponseListener((evt) -> {

            JSONParser j = new JSONParser();

            Map<String, Object> productsJSON = null;
            try {
                productsJSON = j.parseJSON(new CharArrayReader(new String(con.getResponseData()).toCharArray()));
            } catch (IOException ex) {

            }
            List<Map<String, Object>> list = (List<Map<String, Object>>) productsJSON.get("root");

            for (Map<String, Object> obj : list) {
                Product product;

                product = new Product();

                int id = (int) ((double) obj.get("id"));

                product.setId(id);

                Double store_id = (Double) obj.get("store");
                product.setStore(new Store(store_id.intValue()));
                product.setName((String) obj.get("name"));
                product.setDescription((String) obj.get("description"));
                product.setPrice((double) obj.get("price"));
                product.setImage((String) obj.get("image"));
                int quantity = (int) ((double) obj.get("quantity"));
                product.setQuantity(quantity);

                products.add(product);

            }
        });

        NetworkManager.getInstance().addToQueueAndWait(con);
        return products;
    }

    public int countProducts() {
        HiddenObj ho = new HiddenObj(0, true);
        ConnectionRequest con2 = new ConnectionRequest();
        con2.setUrl("http://127.0.0.1:8000/api/countProducts");
        con2.setPost(false);
        con2.addResponseListener((evt) -> {
            ho.setObject(Integer.valueOf(new String(con2.getResponseData())));
        });
        NetworkManager.getInstance().addToQueueAndWait(con2);
        return (int) ho.getObject();
    }
    private Store storeResult = null;

    public Store getStoreByProd(int idProd) {
        storeResult = null;
        con.setUrl("http://127.0.0.1:8000/api/GetStoreByProd/" + idProd);
        con.setPost(false);
        con.addResponseListener((evt) -> {
            try {
                Map<String, Object> storeJSON = jSONParser.parseJSON(new CharArrayReader(new String(con.getResponseData()).toCharArray()));

                if (!storeJSON.isEmpty()) {
                    storeResult = new Store();
                    int id = (int) ((double) storeJSON.get("id"));
                    storeResult.setId(id);
                    storeResult.setName((String) storeJSON.get("name"));
                    storeResult.setEmail((String) storeJSON.get("email"));
                    int phone = (int) ((double) storeJSON.get("phone"));
                    storeResult.setPhone(phone);

                } else {
                    throw new Exception("not found");
                }
            } catch (IOException ex) {
            } catch (Exception ex) {
            }
        });
        NetworkManager.getInstance().addToQueueAndWait(con);
        return storeResult;
    }
}
