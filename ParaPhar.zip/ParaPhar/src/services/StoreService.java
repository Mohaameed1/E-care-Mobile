/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import com.codename1.io.CharArrayReader;
import com.codename1.io.ConnectionRequest;
import com.codename1.io.JSONParser;
import com.codename1.io.NetworkManager;
import entities.Product;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import entities.Store;
import entities.User;
import views.HiddenObj;

/**
 *
 * @author KattaX
 */
public class StoreService {

    private ConnectionRequest con;
    private JSONParser jSONParser;

    public StoreService() {
        con = new ConnectionRequest();

        jSONParser = new JSONParser();
    }

    public List<Store> getAllStores() {
        List<Store> stores = new ArrayList<>();
        con.setUrl("http://127.0.0.1:8000/api/GetStores");
        con.setPost(false);
        con.addResponseListener((evt) -> {

            JSONParser j = new JSONParser();

            Map<String, Object> storesJSON = null;
            try {
                storesJSON = j.parseJSON(new CharArrayReader(new String(con.getResponseData()).toCharArray()));
            } catch (IOException ex) {

            }
            List<Map<String, Object>> list = (List<Map<String, Object>>) storesJSON.get("root");

            for (Map<String, Object> obj : list) {
                Store store;

                store = new Store();

                int id = (int) ((double) obj.get("id"));

                store.setId(id);
                store.setUser_id((User) obj.get("user_id"));

                store.setName((String) obj.get("name"));

                store.setEmail((String) obj.get("email"));
                int phone = (int) ((double) obj.get("phone"));
                store.setPhone(phone);

                stores.add(store);

            }
        });

        NetworkManager.getInstance().addToQueueAndWait(con);
        return stores;
    }

    public int countStores() {
        HiddenObj ho = new HiddenObj(0, true);
        ConnectionRequest con2 = new ConnectionRequest();
        con2.setUrl("http://127.0.0.1:8000/api/countStores");
        con2.setPost(false);
        con2.addResponseListener((evt) -> {
            ho.setObject(Integer.valueOf(new String(con2.getResponseData())));
        });
        NetworkManager.getInstance().addToQueueAndWait(con2);
        return (int) ho.getObject();
    }
    private Store storeResult = null;
    Product prod = new Product();

//    public Store getStoreByProd(Store idp) {
//        storeResult = null;
//        con.setUrl("http://127.0.0.1:8000/api/GetStoreByProd/"+prod.getStore_id().toString());
//        con.setPost(false);
//        con.addResponseListener((evt) -> {
//            try {
//                Map<String, Object> storeJSON = jSONParser.parseJSON(new CharArrayReader(new String(con.getResponseData()).toCharArray()));
//
//                if (!storeJSON.isEmpty()) {
//                    storeResult = new Store();
//                    int id = (int) ((double) storeJSON.get("id"));
//                    storeResult.setId(id);
//                    storeResult.setName((String) storeJSON.get("name"));
//                    storeResult.setEmail((String) storeJSON.get("email"));
//                    int phone = (int) ((double) storeJSON.get("phone"));
//                    storeResult.setPhone(phone);
//                  
//                } else {
//                    throw new Exception("not found");
//                }
//            } catch (IOException ex) {
//            } catch (Exception ex) {
//            }
//        });
//        NetworkManager.getInstance().addToQueueAndWait(con);
//        return storeResult;
//    }
    public Store getStoreByProd(Product prod) {
        Store store = new Store();
        Product product = new Product();

        con.setUrl("http://127.0.0.1:8000/api/GetStoreByProd/" + prod.getStore().getId());

        con.setPost(false);
        con.addResponseListener((evt) -> {

            JSONParser j = new JSONParser();

            Map<String, Object> storesJSON = null;
            try {
                storesJSON = j.parseJSON(new CharArrayReader(new String(con.getResponseData()).toCharArray()));
            } catch (IOException ex) {

            }

            int id = (int) ((double) storesJSON.get("id"));

            store.setId(id);
            store.setUser_id((User) storesJSON.get("user_id"));

            store.setName((String) storesJSON.get("name"));

            store.setEmail((String) storesJSON.get("email"));
            int phone = (int) ((double) storesJSON.get("phone"));
            store.setPhone(phone);

        });

        NetworkManager.getInstance().addToQueueAndWait(con);
        return store;
    }
}
