/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

/**
 *
 * @author KattaX
 */
import entities.User;
import com.codename1.io.CharArrayReader;
import com.codename1.io.ConnectionRequest;
import com.codename1.io.JSONParser;
import com.codename1.io.NetworkEvent;
import com.codename1.io.NetworkManager;
import java.io.IOException;
import java.util.Map;
import utils.UserPara;

public class UserService {

    private final ConnectionRequest con;
    private final JSONParser jSONParser;

    public UserService() {
        con = new ConnectionRequest();
        jSONParser = new JSONParser();
    }

    public boolean existe(String json) {
        boolean existee = false;
        try {
            JSONParser j = new JSONParser();

            Map<String, Object> tasks = j.parseJSON(new CharArrayReader(json.toCharArray()));
            if (tasks != null && tasks.size() > 0 && !tasks.containsKey("error")) {
                existee = true;
                User u = new User();
                //int id = (int) ((double) tasks.get("id"));
                //u.setId(id);
                //u.setRoles((String)tasks.get("roles"));
                u.setPassword((String) tasks.get("password"));
                u.setEmail((String) tasks.get("email"));
                u.setNom((String) tasks.get("nom"));
                //u.setPrenom((String) tasks.get("prenom"));
                //u.setTel((String) tasks.get("tel"));
                UserPara.userConnecte = u;
            }

        } catch (IOException ex) {
        }

        System.out.println(existee);
        return existee;

    }

    static boolean ext;

    public boolean existance(String mail, String pwd) {
        ConnectionRequest conn = new ConnectionRequest();

        conn.setUrl(UserPara.baseURL + "/login/" + mail + "/" + pwd);
        conn.addResponseListener((NetworkEvent evt) -> {
            if (conn.getResponseCode() == 200) {
                UserService ser = new UserService();
                ext = ser.existe(new String(conn.getResponseData()));
                System.out.println("" + ext);
            } else {
                ext = false;
            }
        });
        NetworkManager.getInstance().addToQueueAndWait(conn);
        return ext;
    }

}
