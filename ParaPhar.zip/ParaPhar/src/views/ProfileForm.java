/*
 * Copyright (c) 2016, Codename One
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
 * documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
 * the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, 
 * and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions 
 * of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, 
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT 
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
 * CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE 
 * OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
 */
package views;

import entities.Product;
import services.ProductService;

import com.codename1.components.FloatingActionButton;
import com.codename1.components.InteractionDialog;
import com.codename1.components.MultiButton;
import com.codename1.components.SpanLabel;
import com.codename1.ui.Button;
import com.codename1.ui.Component;
import com.codename1.ui.Container;
import com.codename1.ui.Dialog;
import com.codename1.ui.Display;
import com.codename1.ui.FontImage;
import com.codename1.ui.Graphics;
import com.codename1.ui.Image;
import com.codename1.ui.Label;
import com.codename1.ui.TextArea;
import com.codename1.ui.Toolbar;
import com.codename1.ui.events.ActionEvent;
import com.codename1.ui.events.ActionListener;
import com.codename1.ui.geom.Dimension;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.layouts.FlowLayout;
import com.codename1.ui.layouts.GridLayout;
import com.codename1.ui.plaf.Style;
import com.codename1.ui.util.Resources;
import entities.Store;
import java.util.List;
import java.util.Random;
import services.StoreService;
import utils.UserPara;

/**
 * Represents a user profile in the app, the first form we open after the
 * walkthru
 *
 * @author Shai Almog
 */
public class ProfileForm extends SideMenuBaseForm {

    int[] colors = {0xd997f1, 0x5ae29d, 0x4dc2ff, 0xffc06f};
    private final Resources theme;
    StoreService storeService = new StoreService();
    private Label wishListCount;

    public ProfileForm(Resources res) {
        super(BoxLayout.y());
        this.theme = res;

        Toolbar tb = getToolbar();
        tb.setTitleCentered(false);
        Image profilePic = res.getImage("user-picture.jpg");
        Image mask = res.getImage("round-mask.png");
        profilePic = profilePic.fill(mask.getWidth(), mask.getHeight());
        Label profilePicLabel = new Label(profilePic, "ProfilePicTitle");
        profilePicLabel.setMask(mask.createMask());

        Button menuButton = new Button("");
        menuButton.setUIID("Title");
        FontImage.setMaterialIcon(menuButton, FontImage.MATERIAL_MENU);
        menuButton.addActionListener(e -> getToolbar().openSideMenu());

        ProductService productService = new ProductService();
        List<Product> prods = productService.getAll();

        Container remainingTasks = BoxLayout.encloseY(
                new Label("" + prods.size(), "CenterTitle"),
                new Label("Products", "CenterSubTitle")
        );
        remainingTasks.setUIID("RemainingTasks");

        wishListCount = new Label("" + WishList.getProducts().size(), "CenterTitle");
        Container completedTasks = BoxLayout.encloseY(
                wishListCount,
                new Label("Wishlist", "CenterSubTitle")
        );
        completedTasks.setUIID("CompletedTasks");

        Button actionBtn = new Button();
        actionBtn.addActionListener(e -> {
            new WishList(theme).show();
        });

        completedTasks.setLeadComponent(actionBtn);

        Container titleCmp = BoxLayout.encloseY(
                FlowLayout.encloseIn(menuButton),
                BorderLayout.centerAbsolute(
                        BoxLayout.encloseY(
                                new Label(UserPara.userConnecte.getNom(), "Title"),
                                new Label("UI/UX Designer", "SubTitle")
                        )
                ).add(BorderLayout.WEST, profilePicLabel),
                GridLayout.encloseIn(2, remainingTasks, completedTasks)
        );

        FloatingActionButton fab = FloatingActionButton.createFAB(FontImage.MATERIAL_ADD);
        fab.getAllStyles().setMarginUnit(Style.UNIT_TYPE_PIXELS);
        fab.getAllStyles().setMargin(BOTTOM, completedTasks.getPreferredH() - fab.getPreferredH() / 2);
        fab.setVisible(false);
        tb.setTitleComponent(fab.bindFabToContainer(titleCmp, CENTER, BOTTOM));

//        fab.addActionListener((evt) -> {
//        });
        add(new Label("Products", "TodayTitle"));
        FontImage arrowDown = FontImage.createMaterial(FontImage.MATERIAL_KEYBOARD_ARROW_DOWN, "Label", 3);

        if (prods != null && !prods.isEmpty()) {
            Random r = new Random(123456789);
            for (Product prod : prods) {
                int random = r.nextInt(colors.length);
                //first ?
                if (prods.get(0).equals(prod)) {
                    addButtonBottom(arrowDown, prod, colors[random], true);
                } else {
                    addButtonBottom(arrowDown, prod, colors[random], false);
                }
            };
        }

        setupSideMenu(res);
    }

    private void addButtonBottom(Image arrowDown, Product prod, int color, boolean first) {
        MultiButton finishLandingPage = new MultiButton(prod.getName() != null ? prod.getName() : "product" + prod.getId());
        finishLandingPage.setEmblem(arrowDown);
        finishLandingPage.setUIID("Container");
        finishLandingPage.setUIIDLine1("TodayEntry");
        finishLandingPage.setIcon(createCircleLine(color, finishLandingPage.getPreferredH(), first));
        finishLandingPage.setIconUIID("Container");
        Container C1 = new Container(new BoxLayout(BoxLayout.Y_AXIS));
        HiddenObj hiddenObj = new HiddenObj(prod, true);
        finishLandingPage.addActionListener((evt) -> {
            //C1.setVisible(true);
            C1.setHidden(hiddenObj.isB());
            C1.getParent().animateLayout(200);
            System.out.println("" + ((Label) C1.getComponentAt(0)).getText());
        });
        add(FlowLayout.encloseIn(finishLandingPage));
        //C1.setVisible(false);
        C1.setHidden(true);
        C1.add(new Label("Description: " + prod.getDescription()));
        C1.add(new SpanLabel("Price: " + (int) prod.getPrice() + " " + "TND"));
        C1.add(new SpanLabel("Quantity: " + prod.getQuantity()));
        Button check = new Button("Check Pharmacy");
        check.addActionListener((evt) -> {
            StoreAffiche a = new StoreAffiche(theme, storeService.getStoreByProd(prod));
            a.show();
        });

        Button addToWishList = new Button("Add to wishlist");
        addToWishList.addActionListener((evt) -> {
            WishList.addProduct(prod);
            this.wishListCount.setText(WishList.getProducts().size() + "");
            Dialog.show("Success","Added to whishlist", "Ok","Cancel");
          
        });

        C1.add(check);
        C1.add(addToWishList);
        add(C1);
    }

    private boolean getInverted(Boolean b) {
        b = new Boolean(!b);
        return b;
    }

    private Image createCircleLine(int color, int height, boolean first) {
        Image img = Image.createImage(height, height, 0);
        Graphics g = img.getGraphics();
        g.setAntiAliased(true);
        g.setColor(0xcccccc);
        int y = 0;
        if (first) {
            y = height / 6 + 1;
        }
        g.drawLine(height / 2, y, height / 2, height);
        g.drawLine(height / 2 - 1, y, height / 2 - 1, height);
        g.setColor(color);
        g.fillArc(height / 2 - height / 4, height / 6, height / 2, height / 2, 0, 360);
        return img;
    }

    @Override
    protected void showOtherForm(Resources res) {
        new StatsForm(res).show();
    }
}
