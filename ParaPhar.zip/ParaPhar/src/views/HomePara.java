/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views;

import com.codename1.ui.Button;
import com.codename1.ui.ComboBox;
import com.codename1.ui.Container;
import com.codename1.ui.Dialog;
import com.codename1.ui.Form;
import com.codename1.ui.TextField;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.util.Resources;

/**
 *
 * @author ACER
 */
public class HomePara extends Form {

    TextField NameProdMembre;
    TextField DescProdMembre;
    TextField NameCat;
    Button btnAjout;
    String s1;
    ComboBox<String> cb1 = new ComboBox();

    public HomePara(Resources theme) {

        Container cnt1 = new Container(new BoxLayout(BoxLayout.Y_AXIS));
        NameProdMembre = new TextField("", " Name ");
        DescProdMembre = new TextField("", " Description ");
        NameCat = new TextField("", "name categorie");
        //btnAjout = new Button("reclamer");

        cb1.addItem("Enseignant");
        cb1.addItem("Note");
        cb1.addItem("Autre");

        cnt1.add(NameProdMembre);
        cnt1.add(DescProdMembre);
        cnt1.add(cb1);
        cnt1.add(btnAjout);
        add(cnt1);
        btnAjout.addActionListener((e) -> {

            if (NameProdMembre.getText().equals("")) {
                Dialog.show("ERREUR SAISIE", "TITRE VIDE", "OK", "ANNULER");
            } else if (DescProdMembre.getText().equals("")) {

                Dialog.show("ERREUR SAISIE", "contenu VIDE", "OK", "ANNULER");
            } else {

                if (cb1.getSelectedIndex() == 0) {
                    s1 = "Article";
                }
                if (cb1.getSelectedIndex() == 1) {
                    s1 = "Formation";
                }
                if (cb1.getSelectedItem().equals("Evenement")) {
                    s1 = "Evenement";
                }

                StoreAffiche a = new StoreAffiche(theme, null);
                a.show();
            }
        });

    }

}
