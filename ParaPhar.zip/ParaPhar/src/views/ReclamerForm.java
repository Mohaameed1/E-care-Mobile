/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views;


import com.codename1.charts.ChartComponent;
import com.codename1.components.MultiButton;
import com.codename1.ui.Button;
import com.codename1.ui.ComboBox;
import com.codename1.ui.Container;
import com.codename1.ui.Dialog;
import com.codename1.ui.FontImage;
import com.codename1.ui.Graphics;
import com.codename1.ui.Image;
import com.codename1.ui.Label;
import com.codename1.ui.TextArea;
import com.codename1.ui.TextComponent;
import com.codename1.ui.Toolbar;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.layouts.FlowLayout;
import com.codename1.ui.util.Resources;

/**
 *
 * @author KattaX
 */
//public class ReclamerForm extends OtherForm {

//    public ReclamerForm(Resources res) {
//        super(res, "  New  ", "reclamation");
//        //container
//        TextComponent sujet = new TextComponent().labelAndHint("Sujet");
//        FontImage.setMaterialIcon(sujet.getField().getHintLabel(), FontImage.MATERIAL_PERSON);
//
//        TextComponent desc = new TextComponent().labelAndHint("Description").constraint(TextArea.EMAILADDR);
//        FontImage.setMaterialIcon(desc.getField().getHintLabel(), FontImage.MATERIAL_EMAIL);
//
//        MultiButton b = new MultiButton("Autre");
//        String[] characters = {"Enseignant", "Note", "Autre"};
//        b.addActionListener(e -> {
//            Dialog d = new Dialog();
//            d.setLayout(BoxLayout.y());
//            d.getContentPane().setScrollableY(true);
//            for (int iter = 0; iter < characters.length; iter++) {
//                MultiButton mb = new MultiButton(characters[iter]);
//                d.add(mb);
//                mb.addActionListener(ee -> {
//                    b.setTextLine1(mb.getTextLine1());
//                    d.dispose();
//                    b.revalidate();
//                });
//            }
//            d.showPopupDialog(b);
//        });
//        TextComponent choiceLabel = new TextComponent().labelAndHint("Type");
//        FontImage.setMaterialIcon(choiceLabel.getField().getHintLabel(), FontImage.MATERIAL_EMAIL);
//        choiceLabel.getField().setText("Autre");
//
//        Container choice = new Container(new BoxLayout(BoxLayout.X_AXIS));
//        choice.add("Type");
//        choice.add(b);
//        choice.setUIID("Back_White");
//
//        Button createButton = new Button("Create");
//        createButton.setUIID("LoginButton");
//
//        Container enclosure = BorderLayout.center(BoxLayout.encloseY(
//                sujet, desc, choice, createButton
//        ));
//
//        ReclamationService reclamationService = new ReclamationService();
//
//        createButton.addActionListener((evt) -> {
//            Reclamation r = new Reclamation();
//            r.setDesc(desc.getText());
//            r.setSujet(sujet.getText());
//            try {
//                reclamationService.addReclamation(r);
//                boolean returnVal = Dialog.show("Ajout reclamation", "avec sucess...", "OK", null);
//                new ProfileForm(res).show();
//            } catch (Exception e) {
//                Dialog.show("Ajout reclamation", "echec...", "OK", null);
//            }
//
//        });
//
//        add(BorderLayout.CENTER,
//                enclosure);
//        setupSideMenu(res);
//    }

//    @Override
//    protected void showOtherForm(Resources res) {
//    }
//
//}
