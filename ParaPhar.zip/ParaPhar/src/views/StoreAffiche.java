/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views;

import entities.Product;
import entities.Store;
import entities.User;
import utils.UserPara;
import services.ProductService;
import services.StoreService;

import com.codename1.components.ImageViewer;
import com.codename1.components.SpanLabel;
import com.codename1.ui.Button;
import com.codename1.ui.ComboBox;
import com.codename1.ui.Container;
import com.codename1.ui.EncodedImage;
import com.codename1.ui.Font;
import com.codename1.ui.Form;
import com.codename1.ui.Image;
import com.codename1.ui.Label;
import com.codename1.ui.events.ActionEvent;
import com.codename1.ui.events.ActionListener;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.util.Resources;
import java.util.List;

/**
 *
 * @author ACER
 */
public class StoreAffiche extends Form {

    EncodedImage imc;
    Image img;
    ImageViewer imv;
    public static String TITRE;
    public static String TITREimage;
    public static String TITREcontenue;
    public static String TITREDATE;
    ComboBox<String> cb1 = new ComboBox();

    Store currentStore;

    public StoreAffiche(Resources theme, Store store) {
        EncodedImage imc;
        Image img;
        ImageViewer imv;
        this.currentStore = store;

        setTitle("Store");
        //etToolbar().addCommandToLeftBar("back", null, e -> new WalkthruForm(res).show());
        getToolbar().addCommandToLeftBar("Retour", null, e -> new ProfileForm(theme).show());
        setLayout(new BoxLayout(BoxLayout.Y_AXIS));

        StoreService storeService = new StoreService();
        if (currentStore != null) {
            Container C1 = new Container(new BoxLayout(BoxLayout.Y_AXIS));
            Container C2 = new Container(new BoxLayout(BoxLayout.Y_AXIS));
            Container C3 = new Container(new BoxLayout(BoxLayout.Y_AXIS));
            Container C4 = new Container(new BoxLayout(BoxLayout.Y_AXIS));
            Container C5 = new Container(new BoxLayout(BoxLayout.Y_AXIS));

            Label titreE = new Label("Name: " + currentStore.getName());
            Font font = titreE.getUnselectedStyle().getFont();
            Font newFont = Font.createSystemFont(font.getFace(), Font.STYLE_BOLD, font.getSize());
            titreE.getUnselectedStyle().setFont(newFont);
            SpanLabel contenu = new SpanLabel("etat: " + currentStore.getEmail());
            Label nameCat = new Label("Categorie: ");
            Button btnA = new Button("afficher");

            btnA.addActionListener((ActionListener) (ActionEvent o) -> {
            });

            C1.add(titreE);

            C2.add(contenu);
            C4.add(btnA);
            C3.add(C1);
            C3.add(C2);
            C3.add(C4);

            add(C3);

        }
    }
}
