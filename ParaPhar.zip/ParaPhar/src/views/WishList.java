/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views;

import com.codename1.components.ImageViewer;
import com.codename1.components.SpanLabel;
import com.codename1.ui.ComboBox;
import com.codename1.ui.Container;
import com.codename1.ui.EncodedImage;
import com.codename1.ui.Font;
import com.codename1.ui.Form;
import com.codename1.ui.Image;
import com.codename1.ui.Label;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.util.Resources;
import entities.Product;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ACER
 */
public class WishList extends Form {

    EncodedImage imc;
    Image img;
    ImageViewer imv;
    public static String TITRE;
    public static String TITREimage;
    public static String TITREcontenue;
    public static String TITREDATE;
    ComboBox<String> cb1 = new ComboBox();

    static List<Product> products = new ArrayList<>();

    public WishList(Resources theme) {
        EncodedImage imc;
        Image img;
        ImageViewer imv;

        setTitle("Products");
        //etToolbar().addCommandToLeftBar("back", null, e -> new WalkthruForm(res).show());
        getToolbar().addCommandToLeftBar("Retour", null, e -> new ProfileForm(theme).show());
        getToolbar().addCommandToRightBar("Clear", null, e -> {
            WishList.getProducts().clear();
            initProducts();
        });
        setLayout(new BoxLayout(BoxLayout.Y_AXIS));
        initProducts();
    }

    public static List<Product> getProducts() {
        return products;
    }

    public static void addProduct(Product prod) {
        products.add(prod);
    }

    private void initProducts() {
        //reset data
        removeAll();
        refreshTheme();
        for (Product product : products) {
            Container C1 = new Container(new BoxLayout(BoxLayout.Y_AXIS));
            Container C2 = new Container(new BoxLayout(BoxLayout.Y_AXIS));
            Container C3 = new Container(new BoxLayout(BoxLayout.Y_AXIS));
            Container C4 = new Container(new BoxLayout(BoxLayout.Y_AXIS));
            Container C5 = new Container(new BoxLayout(BoxLayout.Y_AXIS));

            Label titreE = new Label("Name: " + product.getName());
            Font font = titreE.getUnselectedStyle().getFont();
            Font newFont = Font.createSystemFont(font.getFace(), Font.STYLE_BOLD, font.getSize());
            titreE.getUnselectedStyle().setFont(newFont);
            SpanLabel contenu = new SpanLabel("Description: " + product.getDescription());

            C1.add(titreE);

            C2.add(contenu);
            C3.add(C1);
            C3.add(C2);
            C3.add(C4);

            add(C3);
        }
    }
}
