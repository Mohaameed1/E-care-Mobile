-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 15, 2021 at 07:45 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecare`
--

-- --------------------------------------------------------

--
-- Table structure for table `avis`
--

CREATE TABLE `avis` (
  `id` int(11) NOT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `pharmacie_id` int(11) NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `rate` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `avis`
--

INSERT INTO `avis` (`id`, `patient_id`, `pharmacie_id`, `note`, `rate`) VALUES
(3, NULL, 2, 'un trés bon service !', 4);

-- --------------------------------------------------------

--
-- Table structure for table `caract_pat`
--

CREATE TABLE `caract_pat` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `clinique`
--

CREATE TABLE `clinique` (
  `id` int(11) NOT NULL,
  `nomcl` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adressecl` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `numerocl` int(11) NOT NULL,
  `desccl` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `clinique`
--

INSERT INTO `clinique` (`id`, `nomcl`, `adressecl`, `numerocl`, `desccl`) VALUES
(1, 'Clinique 1', 'Tunis', 71001002, 'Clinique');

-- --------------------------------------------------------

--
-- Table structure for table `commentaire`
--

CREATE TABLE `commentaire` (
  `id` int(11) NOT NULL,
  `pseudo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sujet` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `question` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `medecin` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `commentaire`
--

INSERT INTO `commentaire` (`id`, `pseudo`, `sujet`, `question`, `medecin`) VALUES
(1, 'patient', 'ok', '??', 'med1'),
(2, 'rerg', 'rgreg', 'ergrgr²', 'g\'ge'),
(3, 'rffz', 'frgegr', 'zfezf', 'rgrezg'),
(4, 'jhibh', 'j jho', 'nj j', 'med1'),
(5, 'patient', 'ok', '??', 'med1');

-- --------------------------------------------------------

--
-- Table structure for table `doctrine_migration_versions`
--

CREATE TABLE `doctrine_migration_versions` (
  `version` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `execution_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `doctrine_migration_versions`
--

INSERT INTO `doctrine_migration_versions` (`version`, `executed_at`, `execution_time`) VALUES
('DoctrineMigrations\\Version20210303183410', '2021-03-03 18:34:26', 242),
('DoctrineMigrations\\Version20210304092414', '2021-03-04 09:24:21', 1023),
('DoctrineMigrations\\Version20210304111311', '2021-03-04 11:13:23', 42),
('DoctrineMigrations\\Version20210304112154', '2021-03-04 11:22:01', 41),
('DoctrineMigrations\\Version20210305134319', '2021-03-05 13:43:37', 1137),
('DoctrineMigrations\\Version20210306104710', '2021-03-06 10:47:19', 272),
('DoctrineMigrations\\Version20210306111328', '2021-03-06 11:13:33', 117),
('DoctrineMigrations\\Version20210309101436', '2021-03-09 10:14:47', 492),
('DoctrineMigrations\\Version20210309101942', '2021-03-09 10:19:49', 98),
('DoctrineMigrations\\Version20210309202139', '2021-03-09 20:32:47', 239),
('DoctrineMigrations\\Version20210324111252', '2021-03-24 11:13:16', 542),
('DoctrineMigrations\\Version20210324111557', '2021-03-24 11:16:03', 129),
('DoctrineMigrations\\Version20210324111913', '2021-03-24 11:19:20', 117),
('DoctrineMigrations\\Version20210327122727', '2021-03-27 12:27:38', 268),
('DoctrineMigrations\\Version20210330220120', '2021-03-30 22:01:58', 511),
('DoctrineMigrations\\Version20210331001914', '2021-03-31 00:19:23', 277),
('DoctrineMigrations\\Version20210331002634', '2021-03-31 00:26:45', 112),
('DoctrineMigrations\\Version20210331002857', '2021-03-31 00:29:01', 42),
('DoctrineMigrations\\Version20210331002957', '2021-03-31 00:30:02', 40),
('DoctrineMigrations\\Version20210331003146', '2021-03-31 00:31:49', 42),
('DoctrineMigrations\\Version20210331003357', '2021-03-31 00:34:01', 53),
('DoctrineMigrations\\Version20210331003755', '2021-03-31 00:37:59', 199),
('DoctrineMigrations\\Version20210331005216', '2021-03-31 00:52:20', 159),
('DoctrineMigrations\\Version20210331143612', '2021-03-31 14:36:18', 129),
('DoctrineMigrations\\Version20210331144519', '2021-03-31 14:45:24', 132),
('DoctrineMigrations\\Version20210331144859', '2021-03-31 14:49:04', 137),
('DoctrineMigrations\\Version20210331145145', '2021-03-31 14:51:50', 124),
('DoctrineMigrations\\Version20210331145543', '2021-03-31 14:55:46', 62),
('DoctrineMigrations\\Version20210331145642', '2021-03-31 14:56:47', 119),
('DoctrineMigrations\\Version20210331180450', '2021-03-31 18:04:58', 488),
('DoctrineMigrations\\Version20210331180833', '2021-03-31 18:08:59', 102),
('DoctrineMigrations\\Version20210402132639', '2021-04-02 13:27:01', 1616),
('DoctrineMigrations\\Version20210402133655', '2021-04-02 13:37:17', 184),
('DoctrineMigrations\\Version20210402233829', '2021-04-02 23:40:26', 102),
('DoctrineMigrations\\Version20210404141139', '2021-04-04 14:12:40', 502),
('DoctrineMigrations\\Version20210404171354', '2021-04-04 17:14:03', 352),
('DoctrineMigrations\\Version20210404211832', '2021-04-04 21:18:54', 938),
('DoctrineMigrations\\Version20210405222602', '2021-04-05 22:26:15', 399),
('DoctrineMigrations\\Version20210405223808', '2021-04-06 17:03:33', 231),
('DoctrineMigrations\\Version20210406170321', '2021-04-06 17:03:33', 21),
('DoctrineMigrations\\Version20210406174556', '2021-04-06 17:47:41', 111),
('DoctrineMigrations\\Version20210407094743', '2021-04-07 09:47:50', 323),
('DoctrineMigrations\\Version20210407103330', '2021-04-07 10:33:34', 120);

-- --------------------------------------------------------

--
-- Table structure for table `livraison`
--

CREATE TABLE `livraison` (
  `id` int(11) NOT NULL,
  `commande_id` int(11) DEFAULT NULL,
  `nom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adresse` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `numero` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mail` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `medecin`
--

CREATE TABLE `medecin` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prenom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `specialite` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adresse` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sexe` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `num_tel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cin` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'med',
  `id1_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `medecin`
--

INSERT INTO `medecin` (`id`, `nom`, `prenom`, `specialite`, `adresse`, `sexe`, `num_tel`, `cin`, `password`, `role`, `id1_id`) VALUES
(5, 'Dr', 'test111', 'psy', 'tunis', 'H', '42152212', '12335648', 'test', 'med', NULL),
(6, 'Dr AbdLAhmid', 'Boumnijl', 'psy', 'tunis', 'H', '23333333', '3378895', 'test', 'med', NULL),
(9, 'Dr Iheb', 'IIHeb', 'gyneco', 'gabes', 'H', '55644800', '13263875', '1234', 'med', 12),
(10, 'Dr', 'Dr', 'dentiste', 'tunis', 'F', '56888999', '13558866', 'test', 'med', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `panier`
--

CREATE TABLE `panier` (
  `id` int(11) NOT NULL,
  `code_panier` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantite` int(11) NOT NULL,
  `prix_tot` double NOT NULL,
  `produits` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `panier`
--

INSERT INTO `panier` (`id`, `code_panier`, `quantite`, `prix_tot`, `produits`) VALUES
(1, 'kjkjkjk', 3, 422, 'pp/pp/pp'),
(4, 'oooooo', 3, 422, 'pp/pp/pp'),
(6, 'ppppp', 4, 788, 'pp/pp/pp/oo/'),
(8, 'opooo', 2, 142, 'iiii'),
(45, 'opaa', 4, 444, 'iiii'),
(49, 'opp', 2, 142, 'iiii'),
(50, 'kkkk', 4, 500, 'lolo'),
(74, 'opiii', 2, 142, 'iiii'),
(89, 'ahla', 1, 500, 'lled/lpl/lpl'),
(622, 'kkkk', 4, 458, 'lolo'),
(623, 'kkkk', 4, 458, 'lolo'),
(777, 'opooo', 2, 142, 'iiii'),
(778, 'pppp', 1, 7474, 'pp/pp/ppoo'),
(780, '4444', 7, 444, 'pojhjghf'),
(783, '444', 44, 444, '444'),
(784, 'lol', 1, 450, 'pool'),
(785, 'kkkk', 4, 6, 'lolo'),
(787, 'ABC', 1, 1472, 'ea'),
(788, 'ABCD', 4, 1489, 'Ebc'),
(789, 'qwqwqw', 3, 422, 'pp/pp/pp'),
(790, 'kjkjkjkk', 3, 422, 'pp/pp/pp');

-- --------------------------------------------------------

--
-- Table structure for table `panier2`
--

CREATE TABLE `panier2` (
  `id` int(11) NOT NULL,
  `produits` varchar(50) NOT NULL,
  `quantite` int(11) NOT NULL,
  `prix_tot` float NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `panier3`
--

CREATE TABLE `panier3` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` double NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `panier3`
--

INSERT INTO `panier3` (`id`, `name`, `description`, `quantity`, `price`, `image`) VALUES
(1, 'aaaaaaa', 'aaaa', 2, 55454, '');

-- --------------------------------------------------------

--
-- Table structure for table `panier_product`
--

CREATE TABLE `panier_product` (
  `panier_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `panier_produit`
--

CREATE TABLE `panier_produit` (
  `panier_id` int(11) NOT NULL,
  `produit_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `id` int(11) NOT NULL,
  `taille` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `poids` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `maladie_chro` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id1_id` int(11) DEFAULT NULL,
  `nom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prenom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cin` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adresse` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `num_tel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pat'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`id`, `taille`, `poids`, `maladie_chro`, `id1_id`, `nom`, `prenom`, `cin`, `adresse`, `num_tel`, `password`, `role`) VALUES
(1, '183', '75', '', 5, '', '', '', '', '', '', 'pat'),
(3, '', '', '', 99, '', '', '', '', '', '', 'pat');

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `id` int(11) NOT NULL,
  `clinique_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adresse` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pharmacie`
--

CREATE TABLE `pharmacie` (
  `id` int(11) NOT NULL,
  `Nom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Adresse` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Numtel` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pharmacie`
--

INSERT INTO `pharmacie` (`id`, `Nom`, `Adresse`, `Numtel`) VALUES
(1, 'Pharmacie Nabil Kriaa\r\n', '36.890625841013055, 10.165232889447676', 71001002),
(2, 'Pharmacie Mahrajene Amous\r\n', '36.829856843861734, 10.179527716437715', 50502527),
(3, 'Pharmacie Bechraoui Ahmed صيدلية أحمد البشراوي', '33.88516225934154, 10.099964992514163   ', 75214872);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `store_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` double NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `store_id`, `name`, `description`, `quantity`, `price`, `image`) VALUES
(45, 1, 'fervex', 'solution buvable en sachet.', 2000, 3500, '63d0b42c95196f3e9dd33761ac30c783.jpg'),
(46, 1, 'Panadole', 'Ce médicament contient du paracétamol.', 5000, 2500, '79492d661f893fc378338fa66443ad32.jpg'),
(49, 1, 'fervex', 'fervex', 200, 70, '1b64b95b54de59d0d91ed294ae94e031.jpg'),
(50, 1, 'aa', 'c\'est produit', 1, 100, '3a5543013982011f888d6ad10f68e44b.jpg'),
(51, 1, 'aa', 'c\'est produit', 1, 100, 'b4db9926c31623f9e6e911059538a4f8.jpg'),
(53, 2, 'panadolel', 'fff', 2, 3, 'f21893952a581d1fda78f12f11f6b1e8.jpg'),
(54, 2, 'dexeryl', 'Grâce à sa nouvelle formule optimisée.', 900, 6000, 'd1d84d87af65edb2b3d175babdd84c23.jpg'),
(55, 1, 'panadole', 'medicament', 55, 1500, '50e5b5ff1e1940a0058a1af577078a8a.jpg'),
(56, 2, 'marwaaaaa', 'marwaaaaaa', 70000000, 7000000, 'e301f45d1ba042ec64aafbc5520d9277.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `produit`
--

CREATE TABLE `produit` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prix` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantite` int(11) NOT NULL,
  `disponible` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `produit`
--

INSERT INTO `produit` (`id`, `nom`, `prix`, `quantite`, `disponible`) VALUES
(1, 'haded', '4', 1, 1),
(2, 'zrig', '9999999999', 5, 1),
(3, 'assdsa', '54878', 2, 1),
(4, 'klaizer', '5', 3, 1),
(5, 'lele', '50', 1, NULL),
(6, 'assas', '7998', 2, NULL),
(7, 'shruf', '777', 0, 0),
(8, 'zefzef', '879', 1, 1),
(9, 'amorrrri', '24', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `reponse`
--

CREATE TABLE `reponse` (
  `id` int(11) NOT NULL,
  `commentaire_id` int(11) DEFAULT NULL,
  `pseudo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rep` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_rep` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reponse`
--

INSERT INTO `reponse` (`id`, `commentaire_id`, `pseudo`, `rep`, `date_rep`) VALUES
(1, 1, 'med1', 'okk', '2021-04-04 17:15:33'),
(2, 3, 'rthhrg', 'eragreag', '2021-04-04 18:07:24'),
(3, 2, 'rgrea&', 'fegergger', '2021-04-04 18:09:42'),
(4, NULL, 'med1', 'okk', '2021-04-04 19:46:00');

-- --------------------------------------------------------

--
-- Table structure for table `reponse1`
--

CREATE TABLE `reponse1` (
  `id` int(11) NOT NULL,
  `commentaire_id` int(11) NOT NULL,
  `pseudo` varchar(255) NOT NULL,
  `rep` varchar(255) NOT NULL,
  `date_rep` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reponse1`
--

INSERT INTO `reponse1` (`id`, `commentaire_id`, `pseudo`, `rep`, `date_rep`) VALUES
(1, 1, 'ooo', 'ooo', 'oo'),
(4, 4, 'oooykf', 'oookfuk', 'ooou');

-- --------------------------------------------------------

--
-- Table structure for table `representant_clinique`
--

CREATE TABLE `representant_clinique` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prenom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cin` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id1_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `representant_clinique`
--

INSERT INTO `representant_clinique` (`id`, `nom`, `prenom`, `password`, `cin`, `role`, `id1_id`) VALUES
(3, 'rep1', 'rep1', 'test', '', '', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `representant_para`
--

CREATE TABLE `representant_para` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prenom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cin` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id1_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `store`
--

CREATE TABLE `store` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `phone` int(11) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `store`
--

INSERT INTO `store` (`id`, `user_id`, `name`, `phone`, `email`) VALUES
(1, 1, 'BoutiqueM', 98434054, 'marwa@gmail.com'),
(2, 2, 'aaa', 123456789, 'a@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `email` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roles` longtext COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '(DC2Type:json)',
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prenom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `email`, `roles`, `password`, `nom`, `prenom`, `tel`) VALUES
(1, 'adelaide.berger@club-internet.fr', '[\"ROLE_PARA\"]', '$argon2id$v=19$m=65536,t=4,p=1$b3hic1VtM2dMdkJVTmJpNQ$72oERNptF/spPFWUPykHvxsiILJ4sXpcKyKhyXKbb+I', 'adelaide', 'berger', '987564321'),
(2, 'corinne.rousseau@jacquot.com', '[\"ROLE_PARA\"]', '$argon2id$v=19$m=65536,t=4,p=1$bTdya3NCb0YyN0hMRjA4Vw$IhVi3ZwVdM1X6cnMFgReLvfg1XdfHdz8n2t9qmA8YiA', 'corinne', 'rousseau', '25654321');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `avis`
--
ALTER TABLE `avis`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_8F91ABF06B899279` (`patient_id`),
  ADD KEY `IDX_8F91ABF0BC6D351B` (`pharmacie_id`);

--
-- Indexes for table `caract_pat`
--
ALTER TABLE `caract_pat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clinique`
--
ALTER TABLE `clinique`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `commentaire`
--
ALTER TABLE `commentaire`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctrine_migration_versions`
--
ALTER TABLE `doctrine_migration_versions`
  ADD PRIMARY KEY (`version`);

--
-- Indexes for table `livraison`
--
ALTER TABLE `livraison`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_A60C9F1F82EA2E54` (`commande_id`);

--
-- Indexes for table `medecin`
--
ALTER TABLE `medecin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_1BDA53C6231CAD5A` (`id1_id`);

--
-- Indexes for table `panier`
--
ALTER TABLE `panier`
  ADD PRIMARY KEY (`id`),
  ADD KEY `code_panier` (`code_panier`);

--
-- Indexes for table `panier2`
--
ALTER TABLE `panier2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `panier3`
--
ALTER TABLE `panier3`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `panier_product`
--
ALTER TABLE `panier_product`
  ADD PRIMARY KEY (`panier_id`,`product_id`),
  ADD KEY `IDX_29F0C02CF77D927C` (`panier_id`),
  ADD KEY `IDX_29F0C02C4584665A` (`product_id`);

--
-- Indexes for table `panier_produit`
--
ALTER TABLE `panier_produit`
  ADD PRIMARY KEY (`panier_id`,`produit_id`),
  ADD KEY `IDX_D31F28A6F77D927C` (`panier_id`),
  ADD KEY `IDX_D31F28A6F347EFB` (`produit_id`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_1ADAD7EB231CAD5A` (`id1_id`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_2CCC2E2C265183A3` (`clinique_id`);

--
-- Indexes for table `pharmacie`
--
ALTER TABLE `pharmacie`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_D34A04ADB092A811` (`store_id`);

--
-- Indexes for table `produit`
--
ALTER TABLE `produit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reponse`
--
ALTER TABLE `reponse`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_5FB6DEC7BA9CD190` (`commentaire_id`);

--
-- Indexes for table `reponse1`
--
ALTER TABLE `reponse1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `representant_clinique`
--
ALTER TABLE `representant_clinique`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_84BCC997231CAD5A` (`id1_id`);

--
-- Indexes for table `representant_para`
--
ALTER TABLE `representant_para`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_DC663F94231CAD5A` (`id1_id`);

--
-- Indexes for table `store`
--
ALTER TABLE `store`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_FF575877A76ED395` (`user_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_8D93D649E7927C74` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `avis`
--
ALTER TABLE `avis`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `caract_pat`
--
ALTER TABLE `caract_pat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `clinique`
--
ALTER TABLE `clinique`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `commentaire`
--
ALTER TABLE `commentaire`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `livraison`
--
ALTER TABLE `livraison`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `medecin`
--
ALTER TABLE `medecin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `panier`
--
ALTER TABLE `panier`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=791;

--
-- AUTO_INCREMENT for table `panier2`
--
ALTER TABLE `panier2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;

--
-- AUTO_INCREMENT for table `panier3`
--
ALTER TABLE `panier3`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pharmacie`
--
ALTER TABLE `pharmacie`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `produit`
--
ALTER TABLE `produit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `reponse`
--
ALTER TABLE `reponse`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `reponse1`
--
ALTER TABLE `reponse1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `representant_clinique`
--
ALTER TABLE `representant_clinique`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `representant_para`
--
ALTER TABLE `representant_para`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `store`
--
ALTER TABLE `store`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `panier_produit`
--
ALTER TABLE `panier_produit`
  ADD CONSTRAINT `FK_D31F28A6F347EFB` FOREIGN KEY (`produit_id`) REFERENCES `produit` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_D31F28A6F77D927C` FOREIGN KEY (`panier_id`) REFERENCES `panier` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `FK_D34A04ADB092A811` FOREIGN KEY (`store_id`) REFERENCES `store` (`id`);

--
-- Constraints for table `store`
--
ALTER TABLE `store`
  ADD CONSTRAINT `FK_FF575877A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
