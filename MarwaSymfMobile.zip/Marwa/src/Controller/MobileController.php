<?php

namespace App\Controller;

use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Serializer\Normalizer\JsonSerializableNormalizer;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Serializer;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

use App\Entity\Product;
use App\Entity\Store;
use App\Form\ProductType;
use App\Repository\ProductRepository;
use Doctrine\ORM\Query\ResultSetMapping;
use Knp\Bundle\SnappyBundle\Snappy\Response\PdfResponse;

use Doctrine\ORM\Query\ResultSetMappingBuilder;
use App\Entity\User;
use App\Form\StoreType;
use App\Repository\StoreRepository;

/**
 * @Route("/api")
 **/
class MobileController extends AbstractController
{


    /**
     * @Route("/GetProducts", methods={"GET"})
     * @return JsonResponse
     * @throws \Symfony\Component\Serializer\Exception\ExceptionInterface
     */
    public function GetProdsAction(Request $request)
    {

        $em = $this->getDoctrine()->getManager();

        $prodsRepo = $em->getRepository("App:Product");
        $prods = [];

        $prods = $prodsRepo->findAll();


        $ser = new Serializer([new JsonSerializableNormalizer()]);
        return new JsonResponse($ser->normalize($prods));
    }

    /**
     * @Route("/GetStores", methods={"GET"})
     * @return JsonResponse
     * @throws \Symfony\Component\Serializer\Exception\ExceptionInterface
     */
    public function GetStoresAction(Request $request)
    {

        $em = $this->getDoctrine()->getManager();

        $storesRepo = $em->getRepository("App:Store");
        $stores = [];

        $stores = $storesRepo->findAll();


        $ser = new Serializer([new JsonSerializableNormalizer()]);
        return new JsonResponse($ser->normalize($stores));
    }

    /**
     * @Route("/GetStoreByProd/{id}", methods={"GET"})
     * @return JsonResponse
     * @throws \Symfony\Component\Serializer\Exception\ExceptionInterface
     */
    public function GetStoreByProdAction(Request $request, $id)
    {

        $em = $this->getDoctrine()->getManager();
        $store = $em->getRepository("App:Store")->find($id);

        $ser = new Serializer([new JsonSerializableNormalizer()]);
        return new JsonResponse($ser->normalize($store));
    }


    /**
     * @Route("/countProducts", methods={"GET"})
     */
    public function countProductsAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager();
        $prodsRepo = $em->getRepository("App:Product");

        $prods = [];


        $prods = $prodsRepo->findAll();


        return new JsonResponse(count($prods));
    }

    /**
     * @Route("/countStores", methods={"GET"})
     */
    public function countStoresAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager();
        $storesRepo = $em->getRepository("App:Store");

        $stores = [];


        $stores = $storesRepo->findAll();


        return new JsonResponse(count($stores));
    }

    /**
     * @Route("/login/{email}/{password}",name="userLog")
     */
    public function userloginAction($email, $password)
    {
        $em = $this->getDoctrine()->getManager();
        $userRepo = $em->getRepository("App:User");
        $user = $userRepo->findOneBy([
            "email" => $email
        ]);
        if ($user && password_verify($password, $user->getPassword()))

            return $this->json([
                'email' => $user->getEmail(),
                'password' => '',
                'nom' => $user->getNom()
            ]);
        return new JsonResponse(['error' => true]);
    }


}
