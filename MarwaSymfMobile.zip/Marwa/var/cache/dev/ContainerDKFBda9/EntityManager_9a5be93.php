<?php

namespace ContainerDKFBda9;
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'persistence'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'Persistence'.\DIRECTORY_SEPARATOR.'ObjectManager.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolderd9857 = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializerc1d56 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicPropertiesac5af = [
        
    ];

    public function getConnection()
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'getConnection', array(), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'getMetadataFactory', array(), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'getExpressionBuilder', array(), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'beginTransaction', array(), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->beginTransaction();
    }

    public function getCache()
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'getCache', array(), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->getCache();
    }

    public function transactional($func)
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'transactional', array('func' => $func), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->transactional($func);
    }

    public function commit()
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'commit', array(), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->commit();
    }

    public function rollback()
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'rollback', array(), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'getClassMetadata', array('className' => $className), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'createQuery', array('dql' => $dql), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'createNamedQuery', array('name' => $name), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'createQueryBuilder', array(), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'flush', array('entity' => $entity), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'clear', array('entityName' => $entityName), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->clear($entityName);
    }

    public function close()
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'close', array(), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->close();
    }

    public function persist($entity)
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'persist', array('entity' => $entity), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'remove', array('entity' => $entity), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'refresh', array('entity' => $entity), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'detach', array('entity' => $entity), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'merge', array('entity' => $entity), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'getRepository', array('entityName' => $entityName), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'contains', array('entity' => $entity), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'getEventManager', array(), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'getConfiguration', array(), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'isOpen', array(), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'getUnitOfWork', array(), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'getProxyFactory', array(), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'initializeObject', array('obj' => $obj), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'getFilters', array(), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'isFiltersStateClean', array(), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'hasFilters', array(), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return $this->valueHolderd9857->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializerc1d56 = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolderd9857) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolderd9857 = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolderd9857->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, '__get', ['name' => $name], $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        if (isset(self::$publicPropertiesac5af[$name])) {
            return $this->valueHolderd9857->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderd9857;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolderd9857;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, '__set', array('name' => $name, 'value' => $value), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderd9857;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolderd9857;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, '__isset', array('name' => $name), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderd9857;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolderd9857;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, '__unset', array('name' => $name), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolderd9857;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolderd9857;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, '__clone', array(), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        $this->valueHolderd9857 = clone $this->valueHolderd9857;
    }

    public function __sleep()
    {
        $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, '__sleep', array(), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;

        return array('valueHolderd9857');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializerc1d56 = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializerc1d56;
    }

    public function initializeProxy() : bool
    {
        return $this->initializerc1d56 && ($this->initializerc1d56->__invoke($valueHolderd9857, $this, 'initializeProxy', array(), $this->initializerc1d56) || 1) && $this->valueHolderd9857 = $valueHolderd9857;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolderd9857;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolderd9857;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
